const { Given, When, Then } = require('cucumber');
const { Builder, By, Key, until } = require('selenium-webdriver');


Given('Estoy autenticado en Palpet', function () {
    return 'pending';
});

When('Habilito la autenticación de dos factores', function () {
    return 'pending';
});

Then('Debería recibir una confirmación de que el 2FA se ha habilitado con éxito', function () {
    return 'pending';
});

Then('Mi cuenta ahora debería estar protegida con 2FA', function () {
    return 'pending';
});

When('Deshabilito la autenticación de dos factores',  function () {
    return 'pending';
});
    
Then('Debería recibir una confirmación de que el 2FA se ha deshabilitado con éxito', function () {
    return 'pending';
});
    
Then('Mi cuenta ahora debería estar desprotegida con 2FA', function () {
    return 'pending';
});